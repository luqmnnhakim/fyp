-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 23, 2024 at 05:32 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fyp`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_info`
--

CREATE TABLE `admin_info` (
  `adid` int(11) NOT NULL,
  `adusername` varchar(200) NOT NULL,
  `adpassword` varchar(200) NOT NULL,
  `usercat` varchar(200) NOT NULL,
  `adname` varchar(200) NOT NULL,
  `adic` varchar(12) NOT NULL,
  `adgender` char(1) NOT NULL,
  `address` varchar(200) NOT NULL,
  `ademail` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_info`
--

INSERT INTO `admin_info` (`adid`, `adusername`, `adpassword`, `usercat`, `adname`, `adic`, `adgender`, `address`, `ademail`) VALUES
(1, 'luqman', 'luqman123', 'admin', 'Muhammad Luqman', '030630020047', 'M', 'Putrajaya,Malaysia', 'lh8072320@gmail.com'),
(2, 'rafi', 'rafi123', 'staff', 'Rafi Rusyaidi', '030415140047', 'L', 'Putrajaya', 'rafi@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `category` enum('Makanan','Minuman','Set') NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `name`, `price`, `category`, `image`, `description`) VALUES
(1, 'Milo Ais', 2.90, 'Minuman', 'uploads/milo.png', 'Milo Ais ialah minuman sejuk yang dibuat dengan serbuk Milo, susu, gula, dan ais, menghasilkan rasa coklat yang manis dan menyegarkan.'),
(5, 'Nasi Goreng Ayam Hatyai', 7.00, 'Makanan', 'uploads/nasigorengayamhatyai-removebg-preview.png', 'Nasi Goreng Ayam Hatyai ialah nasi goreng berperisa pedas, manis, dan masin, disajikan bersama ayam goreng rangup bercitarasa rempah khas Hatyai, Thailand. Hidangan ini biasanya dilengkapi dengan bawang goreng, timun, dan sambal.'),
(6, 'Nasi Goreng Nenas', 10.00, 'Makanan', 'uploads/nasigorengnenas-removebg-preview.png', 'Nasi Goreng Nenas ialah nasi goreng yang dicampur dengan potongan nenas, sayur, dan kadangkala udang atau ayam, memberikan rasa manis dan masam. Biasanya disajikan dalam kulit nenas untuk tampilan menarik.'),
(7, 'Nasi Goreng Cina', 7.00, 'Makanan', 'uploads/nasigorengcinaori-removebg-preview.png', 'Nasi Goreng Cina ialah nasi goreng yang ringan dan tidak pedas, biasanya digoreng bersama telur, sayur-sayuran, udang, atau ayam, dengan sedikit kicap dan bawang putih. Rasanya lebih sederhana dan segar.'),
(8, 'Teh Tarik', 2.50, 'Minuman', 'uploads/tehtarik.png', 'Teh Tarik ialah minuman teh beraroma yang dicampur dengan susu dan ditarik berulang kali untuk menghasilkan buih serta tekstur yang lembut dan kaya.'),
(9, 'Nasi Goreng Kampung', 6.50, 'Makanan', 'uploads/nasigorengkampung-removebg-preview.png', 'Nasi Goreng Kampung ialah nasi goreng pedas yang dimasak dengan cili, ikan bilis, kangkung, dan sayuran, memberikan rasa tradisional yang kaya dan beraroma.'),
(10, 'Nasi Goreng Thai Udang', 8.00, 'Makanan', 'uploads/nasigorengthaiudang-removebg-preview.png', 'Nasi Goreng Thai Udang ialah nasi goreng berperisa khas Thailand, dimasak bersama udang, cili, bawang putih, dan sos ikan, memberikan rasa pedas, masam, dan sedikit manis.'),
(11, 'Jus Oren', 2.50, 'Minuman', 'uploads/jusoren-removebg-preview.png', 'Jus Oren ialah minuman segar yang dibuat daripada perahan buah oren, memberikan rasa manis dan masam yang kaya dengan vitamin C.'),
(12, 'Kopi Ais', 2.90, 'Minuman', 'uploads/kopiais-removebg-preview.png', 'Kopi Ais ialah minuman kopi yang disajikan sejuk dengan ais, biasanya dicampur dengan susu atau gula untuk menambah rasa.'),
(13, 'Jus Tembikai', 3.50, 'Minuman', 'uploads/justembikai3-removebg-preview.png', 'Jus Tembikai ialah minuman segar yang dibuat daripada perahan tembikai, memberikan rasa manis dan menyegarkan, serta kaya dengan air dan nutrisi.'),
(14, 'Dinner 1', 45.00, 'Set', 'uploads/setdinner1-removebg-preview.png', '1.Nasi\r\n2.kalian\r\n3.Tomyam\r\n4.Telur Dadar\r\n5.Daging Bakar'),
(15, 'Dinner 2', 65.00, 'Set', 'uploads/setdinner2-removebg-preview.png', '1.Nasi\r\n2.Tomyam\r\n3.Ikan Siakap\r\n4.Telur Dadar\r\n5.Kalian');

-- --------------------------------------------------------

--
-- Table structure for table `menu_info`
--

CREATE TABLE `menu_info` (
  `menuid` int(11) NOT NULL,
  `mentype` varchar(200) NOT NULL,
  `menname` varchar(200) NOT NULL,
  `menprice` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu_info`
--

INSERT INTO `menu_info` (`menuid`, `mentype`, `menname`, `menprice`) VALUES
(4, 'Set', 'Bujang', '7'),
(5, 'Drink', 'Milo Ais', '2.5'),
(6, 'Drink', 'Teh O Ais', '1.4');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `salesid` int(11) NOT NULL,
  `salesdate` date NOT NULL,
  `salestotal` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`salesid`, `salesdate`, `salestotal`) VALUES
(6, '2024-10-21', 2.00),
(7, '2024-10-22', 21.00),
(10, '2024-10-23', 84.40);

-- --------------------------------------------------------

--
-- Table structure for table `sales_info`
--

CREATE TABLE `sales_info` (
  `foodid` int(11) NOT NULL,
  `foodname` varchar(200) NOT NULL,
  `drinkname` varchar(200) NOT NULL,
  `totalprice` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales_info`
--

INSERT INTO `sales_info` (`foodid`, `foodname`, `drinkname`, `totalprice`) VALUES
(1, 'Nasi Ayam', 'Milo Ais', 10);

-- --------------------------------------------------------

--
-- Table structure for table `settled_orders`
--

CREATE TABLE `settled_orders` (
  `orid` int(11) NOT NULL,
  `ortable` int(11) NOT NULL,
  `orname` varchar(255) NOT NULL,
  `totalprice` decimal(10,2) NOT NULL,
  `ordate` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `settled_orders`
--

INSERT INTO `settled_orders` (`orid`, `ortable`, `orname`, `totalprice`, `ordate`) VALUES
(9, 1, 'teh ais', 2.00, '2024-10-21 11:27:54'),
(10, 1, 'teh ais', 3.00, '2024-10-21 12:05:35'),
(11, 2, 'teh ais', 3.00, '2024-10-21 12:08:21'),
(12, 4, 'Teh Tarik', 2.50, '2024-10-22 18:38:35'),
(13, 4, 'Nasi Goreng Nenas', 10.00, '2024-10-22 18:38:45'),
(14, 4, 'Jus Oren', 2.50, '2024-10-22 18:38:56'),
(17, 27, 'Nasi Goreng Nenas', 10.00, '2024-10-23 10:42:49'),
(18, 27, 'Nasi Goreng Kampung', 6.50, '2024-10-23 10:43:54'),
(19, 27, 'Milo Ais', 2.90, '2024-10-23 10:44:01'),
(20, 27, 'Dinner 2', 65.00, '2024-10-23 10:44:27');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `orid` int(50) NOT NULL,
  `ortable` int(50) NOT NULL,
  `orname` varchar(200) NOT NULL,
  `totalprice` float NOT NULL,
  `ordate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`orid`, `ortable`, `orname`, `totalprice`, `ordate`) VALUES
(15, 1, 'Nasi Goreng Ayam Hatyai', 7, '2024-10-22 22:52:13'),
(21, 1, 'Nasi Goreng Kampung', 6.5, '2024-10-23 11:24:37'),
(22, 1, 'Nasi Goreng Kampung', 6.5, '2024-10-23 11:24:48');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_info`
--
ALTER TABLE `admin_info`
  ADD PRIMARY KEY (`adid`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu_info`
--
ALTER TABLE `menu_info`
  ADD PRIMARY KEY (`menuid`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`salesid`),
  ADD UNIQUE KEY `salesdate` (`salesdate`);

--
-- Indexes for table `sales_info`
--
ALTER TABLE `sales_info`
  ADD PRIMARY KEY (`foodid`);

--
-- Indexes for table `settled_orders`
--
ALTER TABLE `settled_orders`
  ADD PRIMARY KEY (`orid`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`orid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_info`
--
ALTER TABLE `admin_info`
  MODIFY `adid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `menu_info`
--
ALTER TABLE `menu_info`
  MODIFY `menuid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `salesid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `sales_info`
--
ALTER TABLE `sales_info`
  MODIFY `foodid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `settled_orders`
--
ALTER TABLE `settled_orders`
  MODIFY `orid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `orid` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
